import React, { useState } from 'react';
import { motion, useScroll, useMotionValueEvent, AnimatePresence } from 'framer-motion';
import { Calendar } from 'lucide-react';

export const FloatingCTA: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    // Show after scrolling past hero (approx 800px)
    if (latest > 800) {
      setVisible(true);
    } else {
      setVisible(false);
    }
  });

  return (
    <>
      <AnimatePresence>
        {visible && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            className="fixed bottom-8 right-8 z-50"
          >
            <motion.button
              onClick={() => setIsOpen(true)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="bg-refuge-gold text-white p-4 rounded-full shadow-[0_0_20px_rgba(217,119,6,0.5)] flex items-center justify-center"
            >
              <Calendar size={24} />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-refuge-dark border border-white/10 p-8 rounded-2xl w-full max-w-md relative z-10 shadow-2xl"
            >
              <h3 className="text-2xl font-serif text-white mb-2">Reserve Your Table</h3>
              <p className="text-gray-400 mb-6 text-sm">Join us for an unforgettable evening.</p>
              
              <div className="space-y-4">
                 <div>
                    <label className="block text-xs text-gray-500 uppercase mb-1">Date</label>
                    <input type="date" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white focus:border-refuge-gold outline-none" />
                 </div>
                 <div>
                    <label className="block text-xs text-gray-500 uppercase mb-1">Guests</label>
                    <select className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white focus:border-refuge-gold outline-none">
                       <option>2 People</option>
                       <option>3 People</option>
                       <option>4 People</option>
                       <option>5+ People</option>
                    </select>
                 </div>
                 <button className="w-full bg-refuge-gold py-3 text-white font-bold rounded mt-4 hover:bg-amber-600 transition-colors">
                    Find a Table
                 </button>
              </div>
              
              <button onClick={() => setIsOpen(false)} className="absolute top-4 right-4 text-gray-500 hover:text-white">
                ✕
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};