import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { MenuItem } from '../types';

const menuItems: MenuItem[] = [
  {
    id: '1',
    name: 'Flaming Pretzel',
    description: 'Giant Bavarian pretzel, tableside flambé, beer cheese, spicy mustard.',
    price: '$18',
    category: 'starter',
    image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=1971&auto=format&fit=crop',
    isSignature: true,
  },
  {
    id: '2',
    name: 'Chorizo Pizza',
    description: 'Wood-fired crust, manchego, spicy chorizo, honey drizzle, arugula.',
    price: '$24',
    category: 'main',
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?q=80&w=2080&auto=format&fit=crop',
  },
  {
    id: '3',
    name: 'Tuna Tartare Tacos',
    description: 'Crispy wonton shell, avocado mousse, soy-ginger glaze, sesame.',
    price: '$22',
    category: 'starter',
    image: 'https://images.unsplash.com/photo-1553659971-f01207815844?q=80&w=2064&auto=format&fit=crop',
  },
  {
    id: '4',
    name: 'Seafood Paella Risotto',
    description: 'Saffron arborio rice, lobster tail, clams, mussels, peas, roasted pepper.',
    price: '$42',
    category: 'main',
    image: 'https://images.unsplash.com/photo-1534080564583-6be75777b70a?q=80&w=2070&auto=format&fit=crop',
  },
];

const Card: React.FC<{ item: MenuItem; index: number }> = ({ item, index }) => {
  return (
    <motion.div 
      className="group relative flex-shrink-0 w-[300px] md:w-[400px] h-[500px] rounded-2xl overflow-hidden bg-refuge-dark/50 border border-white/5 backdrop-blur-sm"
      initial={{ opacity: 0, y: 100, rotateX: -15 }}
      whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
      transition={{ duration: 0.8, delay: index * 0.1, ease: "easeOut" }}
      viewport={{ margin: "-100px" }}
      whileHover={{ y: -20, transition: { duration: 0.3 } }}
    >
      <div className="absolute inset-0 z-0">
        <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
        <div className="absolute inset-0 bg-gradient-to-t from-refuge-dark via-refuge-dark/40 to-transparent opacity-90" />
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-8 z-10 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
        {item.isSignature && (
          <span className="inline-block px-3 py-1 mb-3 text-xs font-bold text-black bg-refuge-gold rounded-full uppercase tracking-wider">
            Signature
          </span>
        )}
        <div className="flex justify-between items-end mb-2">
          <h3 className="text-2xl font-serif font-bold text-white group-hover:text-refuge-accent transition-colors">
            {item.name}
          </h3>
          <span className="text-xl font-serif text-refuge-gold italic">{item.price}</span>
        </div>
        <p className="text-sm text-gray-300 font-sans leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
          {item.description}
        </p>
      </div>
    </motion.div>
  );
};

export const Menu: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  });

  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-20%"]);

  return (
    <section id="menu" className="py-24 bg-refuge-dark overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-6 mb-16 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <span className="text-refuge-accent uppercase tracking-[0.2em] text-sm font-semibold">Culinary Fusion</span>
          <h2 className="text-5xl md:text-6xl font-serif font-bold text-white mt-4">Menu Highlights</h2>
        </motion.div>
      </div>

      <div className="relative pl-6 md:pl-[max(2rem,calc((100vw-80rem)/2))]">
        {/* Decorative background text */}
        <motion.div 
          style={{ x }} 
          className="absolute top-0 left-0 whitespace-nowrap text-[12rem] font-bold font-serif text-white/[0.02] pointer-events-none select-none z-0"
        >
          TASTE THE PASSION
        </motion.div>

        <div className="flex gap-8 overflow-x-auto pb-12 pt-12 no-scrollbar px-6" style={{ perspective: '1000px' }}>
          {menuItems.map((item, index) => (
            <Card key={item.id} item={item} index={index} />
          ))}
          
          {/* View Full Menu Card */}
          <motion.div 
            className="flex-shrink-0 w-[300px] md:w-[400px] h-[500px] rounded-2xl border-2 border-dashed border-white/20 flex items-center justify-center group cursor-pointer hover:border-refuge-gold hover:bg-white/5 transition-all"
            initial={{ opacity: 0, x: 100 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <div className="text-center group-hover:scale-110 transition-transform">
              <span className="block text-xl font-serif text-white mb-2">View Full Menu</span>
              <span className="w-12 h-12 rounded-full border border-refuge-gold flex items-center justify-center mx-auto text-refuge-gold">
                →
              </span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};