import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

export const Hero: React.FC = () => {
  const targetRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start start", "end start"],
  });

  // Smooth out the scroll progress
  const smoothProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });

  // Parallax layers
  const backgroundY = useTransform(smoothProgress, [0, 1], ["0%", "50%"]);
  const textY = useTransform(smoothProgress, [0, 1], ["0%", "150%"]);
  const textOpacity = useTransform(smoothProgress, [0, 0.5], [1, 0]);
  
  // Simulated Video Scrub / Frame Reveal
  // As we scroll, the main dish image scales up and rotates slightly to simulate camera movement
  const dishScale = useTransform(smoothProgress, [0, 1], [0.8, 1.2]);
  const dishRotate = useTransform(smoothProgress, [0, 1], [0, 15]);
  const dishY = useTransform(smoothProgress, [0, 1], ["10%", "-10%"]);
  
  // Fire particles simulation
  const fireOpacity = useTransform(smoothProgress, [0, 0.3, 0.6], [0, 1, 0.2]);
  const fireScale = useTransform(smoothProgress, [0, 1], [0.5, 1.5]);

  return (
    <div ref={targetRef} className="h-[150vh] relative overflow-hidden bg-refuge-dark">
      {/* Sticky container for the visual effect */}
      <div className="sticky top-0 h-screen w-full overflow-hidden flex items-center justify-center">
        
        {/* Deep background layer - Slow moving */}
        <motion.div 
          style={{ y: backgroundY }}
          className="absolute inset-0 z-0"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-refuge-dark/40 to-refuge-dark z-10" />
          <img 
            src="https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?q=80&w=2070&auto=format&fit=crop" 
            alt="Moody bar background" 
            className="w-full h-full object-cover opacity-60"
          />
        </motion.div>

        {/* Floating Embers / Fire Particles (Simulated) */}
        <motion.div 
          style={{ opacity: fireOpacity, scale: fireScale }}
          className="absolute inset-0 z-10 pointer-events-none mix-blend-screen"
        >
           {/* Abstract representations of fire/embers using gradients */}
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-orange-500/30 via-red-500/10 to-transparent blur-3xl rounded-full" />
           <div className="absolute top-[60%] left-[40%] w-32 h-32 bg-orange-400 blur-2xl animate-pulse rounded-full opacity-60" />
           <div className="absolute top-[55%] left-[60%] w-24 h-48 bg-refuge-gold blur-xl animate-bounce opacity-40" />
        </motion.div>

        {/* Main Subject - The "Video Scrub" Dish */}
        <motion.div 
          style={{ scale: dishScale, rotate: dishRotate, y: dishY }}
          className="relative z-20 w-[80vw] max-w-2xl aspect-square md:aspect-video flex items-center justify-center"
        >
          {/* Using a high quality image of food with fire/smoke */}
          <img 
            src="https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=2069&auto=format&fit=crop" 
            alt="Flaming Signature Dish" 
            className="w-full h-full object-contain drop-shadow-[0_20px_50px_rgba(217,119,6,0.2)]"
          />
          
          {/* Overlay smoke effect */}
          <div className="absolute inset-0 bg-gradient-to-t from-refuge-dark/80 via-transparent to-transparent mix-blend-overlay" />
        </motion.div>

        {/* Hero Text Layer - Fastest moving */}
        <motion.div 
          style={{ y: textY, opacity: textOpacity }}
          className="absolute z-30 text-center px-4"
        >
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            <h2 className="text-refuge-gold font-script text-4xl md:text-6xl mb-4">Taste the Fire</h2>
            <h1 className="text-6xl md:text-9xl font-serif font-bold text-white tracking-tighter mb-6 drop-shadow-2xl">
              THE REFUGE
            </h1>
            <p className="text-refuge-cream/80 font-sans text-lg md:text-xl tracking-widest uppercase border-t border-b border-refuge-gold/30 py-4 inline-block">
              Latin & Italian Fusion • Melville, NY
            </p>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div 
          style={{ opacity: textOpacity }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 z-30 text-white/50 flex flex-col items-center gap-2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <span className="text-xs uppercase tracking-widest">Scroll to Explore</span>
          <ChevronDown />
        </motion.div>

      </div>
    </div>
  );
};