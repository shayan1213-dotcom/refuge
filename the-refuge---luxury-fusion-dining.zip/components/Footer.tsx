import React from 'react';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Twitter } from 'lucide-react';
import { motion } from 'framer-motion';

export const Footer: React.FC = () => {
  return (
    <footer id="location" className="bg-black text-white pt-24 pb-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-4 gap-12 mb-16">
        
        {/* Brand */}
        <div className="md:col-span-1">
          <div className="text-3xl font-serif font-bold mb-6 text-refuge-gold">THE REFUGE</div>
          <p className="text-gray-400 text-sm leading-relaxed mb-6">
            A sanctuary for the senses. Experience the best of Latin and Italian fusion in a setting designed to inspire.
          </p>
          <div className="flex gap-4">
            {[Instagram, Facebook, Twitter].map((Icon, i) => (
              <motion.a 
                key={i} 
                href="#" 
                whileHover={{ y: -5, color: '#d97706' }}
                className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 transition-colors"
              >
                <Icon size={18} />
              </motion.a>
            ))}
          </div>
        </div>

        {/* Contact */}
        <div>
          <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-refuge-accent">Contact</h4>
          <ul className="space-y-4 text-gray-400 text-sm">
            <li className="flex items-start gap-3">
              <MapPin size={18} className="text-refuge-gold mt-1 flex-shrink-0" />
              <span>515 Broadhollow Rd,<br/>Melville, NY 11747</span>
            </li>
            <li className="flex items-center gap-3">
              <Phone size={18} className="text-refuge-gold flex-shrink-0" />
              <span>(631) 555-0199</span>
            </li>
            <li className="flex items-center gap-3">
              <Mail size={18} className="text-refuge-gold flex-shrink-0" />
              <span>reservations@refugeny.com</span>
            </li>
          </ul>
        </div>

        {/* Hours */}
        <div>
           <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-refuge-accent">Hours</h4>
           <ul className="space-y-2 text-gray-400 text-sm">
             <li className="flex justify-between">
               <span>Mon - Thu</span>
               <span className="text-white">4pm - 11pm</span>
             </li>
             <li className="flex justify-between">
               <span>Fri - Sat</span>
               <span className="text-white">4pm - 2am</span>
             </li>
             <li className="flex justify-between">
               <span>Sun</span>
               <span className="text-white">11am - 10pm</span>
             </li>
             <li className="mt-4 text-xs text-refuge-gold italic">Happy Hour Daily 4pm-7pm</li>
           </ul>
        </div>

        {/* Newsletter */}
        <div>
          <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-refuge-accent">Newsletter</h4>
          <p className="text-gray-400 text-xs mb-4">Subscribe for exclusive invites and seasonal updates.</p>
          <form className="flex flex-col gap-2">
            <input 
              type="email" 
              placeholder="Your email address" 
              className="bg-white/5 border border-white/10 px-4 py-3 text-sm focus:outline-none focus:border-refuge-gold rounded-sm"
            />
            <button className="bg-refuge-gold text-white font-bold text-xs uppercase tracking-widest py-3 hover:bg-amber-600 transition-colors rounded-sm">
              Subscribe
            </button>
          </form>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-xs text-gray-600 gap-4">
        <p>&copy; 2026 The Refuge. All rights reserved.</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-gray-400">Privacy Policy</a>
          <a href="#" className="hover:text-gray-400">Terms of Service</a>
        </div>
        
        {/* LGBTQ Badge Animation */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.5 }}
          whileInView={{ opacity: 1, scale: 1 }}
          className="flex items-center gap-2 bg-white/5 px-3 py-1 rounded-full border border-white/10"
        >
          <div className="flex gap-0.5 h-3 w-4">
            <div className="w-1 bg-red-500 h-full"></div>
            <div className="w-1 bg-orange-500 h-full"></div>
            <div className="w-1 bg-yellow-500 h-full"></div>
            <div className="w-1 bg-green-500 h-full"></div>
            <div className="w-1 bg-blue-500 h-full"></div>
            <div className="w-1 bg-purple-500 h-full"></div>
          </div>
          <span className="text-[10px] text-gray-400 uppercase tracking-wider">All Welcome</span>
        </motion.div>
      </div>
    </footer>
  );
};