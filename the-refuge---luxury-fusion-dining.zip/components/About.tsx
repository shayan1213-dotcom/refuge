import React from 'react';
import { motion } from 'framer-motion';

export const About: React.FC = () => {
  return (
    <section id="story" className="py-24 bg-refuge-dark relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          
          {/* Image Grid with Parallax Hover */}
          <div className="relative h-[600px] w-full">
            <motion.div 
              className="absolute top-0 left-0 w-3/4 h-3/4 overflow-hidden rounded-lg shadow-2xl border border-white/5"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.unsplash.com/photo-1559339352-11d035aa65de?q=80&w=1974&auto=format&fit=crop" 
                alt="Interior" 
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-700 ease-out"
              />
            </motion.div>
            
            <motion.div 
              className="absolute bottom-0 right-0 w-2/3 h-2/3 overflow-hidden rounded-lg shadow-2xl border border-refuge-accent/20 z-10"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=2070&auto=format&fit=crop" 
                alt="Chef Plating" 
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-refuge-accent/10 mix-blend-overlay pointer-events-none" />
            </motion.div>

            {/* Decorative Element */}
            <motion.div 
              className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] border border-white/5 rounded-full"
              animate={{ rotate: 360 }}
              transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
            />
          </div>

          {/* Text Content */}
          <div className="relative">
             <motion.div
               initial={{ opacity: 0, x: 50 }}
               whileInView={{ opacity: 1, x: 0 }}
               transition={{ duration: 0.8 }}
               viewport={{ once: true }}
             >
                <div className="flex items-center gap-4 mb-6">
                  <div className="h-[1px] w-12 bg-refuge-gold" />
                  <span className="text-refuge-gold uppercase tracking-widest text-sm font-bold">Our Story</span>
                </div>
                <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-8 leading-tight">
                  Where <span className="text-refuge-accent italic">Latin Spirit</span> <br/>
                  Meets <span className="text-refuge-gold italic">Italian Soul</span>
                </h2>
                <p className="text-refuge-cream/80 font-sans leading-relaxed mb-6 text-lg">
                  Nestled in the heart of Melville, The Refuge is more than a restaurant—it's an escape. 
                  We bring the fiery passion of Latin American cuisine and marry it with the rustic elegance 
                  of Italian tradition.
                </p>
                <p className="text-refuge-cream/60 font-sans leading-relaxed mb-10">
                  From our wood-fired pizzas with chorizo crumble to our signature paella risotto, 
                  every dish tells a story of cultural convergence. Experience a dining atmosphere 
                  designed to provoke the senses.
                </p>

                <div className="flex gap-4">
                  <div className="flex flex-col">
                    <span className="text-3xl font-serif text-refuge-gold">20+</span>
                    <span className="text-xs uppercase tracking-wider text-white/50">Signature Cocktails</span>
                  </div>
                  <div className="w-[1px] h-12 bg-white/10 mx-4" />
                   <div className="flex flex-col">
                    <span className="text-3xl font-serif text-refuge-gold">100%</span>
                    <span className="text-xs uppercase tracking-wider text-white/50">Farm to Table</span>
                  </div>
                </div>
             </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};